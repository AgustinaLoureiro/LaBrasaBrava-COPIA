// brasa-loader.jsx — Brasa Brava fire-logo loading animation.
// Single continuous flicker loop (2.4s = 2x each oscillation period) so the
// last authored frame matches the first — safe to loop indefinitely.

const VARIANTS = {
  orange: { img: 'uploads/logo-bb.png', bg: '#241d19', glow: '226,120,58' },
  carbon: { img: 'uploads/logo-bb-carbon.png', bg: '#f2e6d2', glow: '43,36,31' },
  crema: { img: 'uploads/logo-bb-crema.png', bg: '#241d19', glow: '238,221,190' },
};

const EMBERS = [
  { phase: 0.00, x: -34, drift: 10, size: 7 },
  { phase: 0.35, x: 18, drift: -14, size: 5 },
  { phase: 0.65, x: -8, drift: 16, size: 6 },
  { phase: 0.90, x: 40, drift: -8, size: 4 },
  { phase: 1.15, x: -50, drift: 6, size: 5 },
  { phase: 1.45, x: 6, drift: -10, size: 6 },
];
const EMBER_PERIOD = 1.2;
const EMBER_RISE = 190;

function Ember(props) {
  const { t, e } = props;
  const local = ((t + e.phase) % EMBER_PERIOD + EMBER_PERIOD) % EMBER_PERIOD;
  const frac = local / EMBER_PERIOD;
  const y = -frac * EMBER_RISE;
  const x = e.x + Math.sin(frac * Math.PI * 2) * e.drift;
  const opacity = Math.sin(Math.PI * frac);
  const scale = 1 - frac * 0.65;
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '42%',
      width: e.size, height: e.size, borderRadius: '50%',
      background: 'radial-gradient(circle, #ffcf8a 0%, #e2793a 55%, rgba(226,121,58,0) 100%)',
      transform: `translate(${x}px, ${y}px) scale(${scale})`,
      opacity: Math.max(0, opacity) * 0.9,
      pointerEvents: 'none',
    }} />
  );
}

function FlamePiece(props) {
  const { T } = useComposition();
  const v = VARIANTS[props.variant] || VARIANTS.orange;

  const scale = 1
    + 0.018 * Math.sin((2 * Math.PI * T) / 1.2)
    + 0.010 * Math.sin((2 * Math.PI * T) / 0.4 + 1.3);
  const skew = 0.6 * Math.sin((2 * Math.PI * T) / 0.6 + 0.5);
  const brightness = 1
    + 0.08 * Math.sin((2 * Math.PI * T) / 0.8)
    + 0.035 * Math.sin((2 * Math.PI * T) / 0.3 + 2.1);
  const glowBlur = 46 + 12 * Math.sin((2 * Math.PI * T) / 0.8);
  const glowOpacity = 0.55 + 0.18 * Math.sin((2 * Math.PI * T) / 0.8);

  return (
    <div style={{ position: 'absolute', inset: 0, background: v.bg, overflow: 'hidden' }}>
      <div style={{
        position: 'absolute', left: '50%', top: '46%', width: 520, height: 520,
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, rgba(${v.glow},${glowOpacity}) 0%, rgba(${v.glow},0) 70%)`,
        filter: `blur(${glowBlur * 0.4}px)`,
      }} />
      {EMBERS.map((e, i) => <Ember key={i} t={T} e={e} />)}
      <img src={v.img} alt="Brasa Brava" style={{
        position: 'absolute', left: '50%', top: '46%', width: 380, height: 380,
        transform: `translate(-50%, -50%) scale(${scale}) skewX(${skew}deg)`,
        filter: `brightness(${brightness}) drop-shadow(0 0 ${glowBlur}px rgba(${v.glow},${glowOpacity * 0.8}))`,
      }} />
    </div>
  );
}

function BrasaLoader(props) {
  const v = VARIANTS[props.variant] || VARIANTS.orange;
  return (
    <CompositionStage width={800} height={800} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={v.bg}>
      <FlamePiece variant={props.variant} />
    </CompositionStage>
  );
}

window.BrasaLoader = BrasaLoader;
