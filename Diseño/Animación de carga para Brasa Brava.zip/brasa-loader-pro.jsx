// brasa-loader-pro.jsx — refined multi-stage Brasa Brava loading animation.
// Ignite (mask reveal) -> Wordmark settle -> Ember Loop (breathing flame,
// rotating progress ring, rising embers).

const VARIANTS = {
  orange: { img: 'uploads/logo-bb.png', bg: '#1a1512', vignette: '#0d0a08', glow: '226,120,58', ring: '226,150,90', text: '#f4e9dc' },
  carbon: { img: 'uploads/logo-bb-carbon.png', bg: '#f2e6d2', vignette: '#e6d6b8', glow: '43,36,31', ring: '90,76,64', text: '#2b2420' },
  crema: { img: 'uploads/logo-bb-crema.png', bg: '#1a1512', vignette: '#0d0a08', glow: '238,221,190', ring: '238,221,190', text: '#f4e9dc' },
};

const EMBERS = [
  { phase: 0.00, x: -46, drift: 12, size: 6 },
  { phase: 0.30, x: 30, drift: -16, size: 4 },
  { phase: 0.55, x: -14, drift: 18, size: 5 },
  { phase: 0.80, x: 52, drift: -10, size: 3 },
  { phase: 1.05, x: -60, drift: 8, size: 4 },
];
const EMBER_PERIOD = 1.2;
const EMBER_RISE = 210;

const Easing = window.Easing;
const easeOutCubic = Easing ? Easing.easeOutCubic : (t) => 1 - Math.pow(1 - t, 3);
const easeOutBack = Easing ? Easing.easeOutBack : (t) => t;

function Ember(props) {
  const { t, e, active } = props;
  if (!active) return null;
  const local = ((t + e.phase) % EMBER_PERIOD + EMBER_PERIOD) % EMBER_PERIOD;
  const frac = local / EMBER_PERIOD;
  const y = -frac * EMBER_RISE;
  const x = e.x + Math.sin(frac * Math.PI * 2) * e.drift;
  const opacity = Math.max(0, Math.sin(Math.PI * frac));
  const scale = 1 - frac * 0.6;
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '44%',
      width: e.size, height: e.size, borderRadius: '50%',
      background: 'radial-gradient(circle, #ffd9a0 0%, #e2793a 55%, rgba(226,121,58,0) 100%)',
      filter: 'blur(0.4px)',
      transform: `translate(${x}px, ${y}px) scale(${scale})`,
      opacity: opacity * 0.85,
      pointerEvents: 'none',
    }} />
  );
}

function ProgressRing(props) {
  const { T, v, entrance } = props;
  const angle = (T * 95) % 360;
  const dash = 130 * (0.35 + 0.1 * Math.sin((2 * Math.PI * T) / 2.4));
  return (
    <svg width="440" height="440" style={{
      position: 'absolute', left: '50%', top: '46%', transform: 'translate(-50%,-50%)',
      opacity: entrance * 0.9,
    }}>
      <circle cx="220" cy="220" r="196" fill="none" stroke={`rgba(${v.ring},0.16)`} strokeWidth="1.5" />
      <circle
        cx="220" cy="220" r="196" fill="none"
        stroke={`rgba(${v.ring},0.85)`} strokeWidth="2"
        strokeDasharray={`${dash} 1200`} strokeLinecap="round"
        transform={`rotate(${angle} 220 220)`}
      />
    </svg>
  );
}

function FlamePiece(props) {
  const { T, CUES } = useComposition();
  const v = VARIANTS[props.variant] || VARIANTS.orange;

  const ignite = clamp((T - CUES.Ignite) / (CUES['Reveal Wordmark'] - CUES.Ignite), 0, 1);
  const igniteEased = easeOutCubic(ignite);
  const wordT = clamp((T - CUES['Reveal Wordmark']) / (CUES['Ember Loop'] - CUES['Reveal Wordmark']), 0, 1);
  const wordEased = easeOutBack(wordT);

  const flickerAmp = ignite; // ramps flicker in as flame reveals
  const scale = 0.94 + 0.06 * igniteEased
    + flickerAmp * (0.016 * Math.sin((2 * Math.PI * T) / 1.2) + 0.009 * Math.sin((2 * Math.PI * T) / 0.4 + 1.3));
  const skew = flickerAmp * 0.6 * Math.sin((2 * Math.PI * T) / 0.6 + 0.5);
  const brightness = 0.7 + 0.3 * igniteEased
    + flickerAmp * (0.07 * Math.sin((2 * Math.PI * T) / 0.8) + 0.03 * Math.sin((2 * Math.PI * T) / 0.3 + 2.1));
  const glowBlur = 40 + 14 * Math.sin((2 * Math.PI * T) / 0.8);
  const glowOpacity = igniteEased * (0.5 + 0.2 * Math.sin((2 * Math.PI * T) / 0.8));

  const revealClip = `inset(${(1 - igniteEased) * 100}% 0 0 0)`;

  return (
    <div style={{ position: 'absolute', inset: 0, background: v.bg, overflow: 'hidden' }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(circle at 50% 42%, ${v.bg} 0%, ${v.vignette} 100%)`,
      }} />
      <div style={{
        position: 'absolute', left: '50%', top: '44%', width: 560, height: 560,
        transform: 'translate(-50%, -50%)',
        background: `radial-gradient(circle, rgba(${v.glow},${glowOpacity}) 0%, rgba(${v.glow},0) 70%)`,
        filter: `blur(${glowBlur * 0.4}px)`,
      }} />
      <ProgressRing T={T} v={v} entrance={igniteEased} />
      {EMBERS.map((e, i) => <Ember key={i} t={T} e={e} active={ignite > 0.5} />)}
      <div style={{
        position: 'absolute', left: '50%', top: '44%', width: 360, height: 360,
        transform: `translate(-50%, -50%) scale(${scale}) skewX(${skew}deg)`,
        clipPath: revealClip,
        filter: `brightness(${brightness}) drop-shadow(0 0 ${glowBlur}px rgba(${v.glow},${glowOpacity * 0.8}))`,
      }}>
        <img src={v.img} alt="Brasa Brava" style={{ width: '100%', height: '100%' }} />
      </div>
      <div style={{
        position: 'absolute', left: '50%', top: '68%', transform: `translate(-50%, ${(1 - wordEased) * 14}px)`,
        opacity: wordEased,
        color: v.text, fontFamily: 'Georgia, "Times New Roman", serif',
        fontSize: 30, letterSpacing: 6, fontWeight: 400, textAlign: 'center', whiteSpace: 'nowrap',
      }}>BRASA BRAVA</div>
    </div>
  );
}

function BrasaLoaderPro(props) {
  const v = VARIANTS[props.variant] || VARIANTS.orange;
  return (
    <CompositionStage width={800} height={800} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg={v.bg}>
      <FlamePiece variant={props.variant} />
    </CompositionStage>
  );
}

window.BrasaLoaderPro = BrasaLoaderPro;
